from Tkinter import *
import numpy as np
from scipy.integrate import odeint
from pydelay import dde23
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import random

print " ____   _  _  _  _    __    ___  _  _  ___  _____ "
print "(  _ \ ( \/ )( \( )  /__\  / __)( \/ )/ __)(_   _)"
print " )(_) ) \  /  )  (  /(__)\ \__ \ \  / \__ \  ) ("
print "(____/  (__) (_)\_)(__)(__)(___/ (__) (___/ (___)"
print ""
print "============================================"

master = Tk()

master.title("1. It's DYNASYS man!")

#---------------------------------------------------------
ffile="icon/icon"+str(random.randint(1,8))+".png"
#print(ffile)
background_image=PhotoImage(file=ffile)
background_label =Label(master, image=background_image,bg="honeydew")
background_label.place(x=0, y=0, relwidth=1, relheight=1)
background_label.grid(row=0,column=0,columnspan=6,rowspan=6)
#---------------------------------------------------------

def var_states():
    print("Lorenz System: %d,\nRossler System: %d" % (var1.get(), var2.get()))

def run_prog():
    if var1.get()==0 and var2.get()==0 and var3.get()==0 \
    and var4.get()==0 and var5.get()==0 and var6.get()==0 \
    and var7.get()==0 and var8.get()==0 and var9.get()==0 \
    and var10.get()==0:
        print "Error1: Check one of the listed systems"
    #----LORENZ---------------
    elif var1.get()==1 and var2.get()==0 and var3.get()==0 \
    and var4.get()==0 and var5.get()==0 and var6.get()==0 \
    and var7.get()==0  and var8.get()==0 and var9.get()==0 \
    and var10.get()==0:
        execfile("systems/ode/lorenz_bif.py")
    #----ROSSLER---------------
    elif var2.get()==1 and var3.get()==0 and var4.get()==0 \
    and var5.get()==0 and var6.get()==0 and var7.get()==0 \
    and var8.get()==0 and var9.get()==0 and var10.get()==0:
        execfile("systems/ode/rossler_bif.py")
    #----LOTKA-VOLTERRA---------------
    elif var3.get()==1 and var4.get()==0 and var5.get()==0 \
    and var6.get()==0 and var7.get()==0 and var8.get()==0 \
    and var9.get()==0 and var10.get()==0:
        execfile("systems/ode/predator_prey.py")
    #----MACKEY-GLASS---------------
    elif var4.get()==1 and var5.get()==0 and var6.get()==0 \
    and var7.get()==0 and var8.get()==0 and var9.get()==0 \
    and var10.get()==0:
        execfile("systems/dde/mg.py")
    #----DDEX---------------
    elif var5.get()==1 and var6.get()==0 and var7.get()==0 \
    and var8.get()==0 and var9.get()==0 and var10.get()==0:
        execfile("systems/dde/ddex_slider_grid.py")
    #----DDEHW---------------
    elif var6.get()==1 and var7.get()==0 and var8.get()==0 \
    and var9.get()==0 and var10.get()==0:
        execfile("systems/dde/ddehw_pydelay.py")
    #----LOGISTIC---------------
    elif var7.get()==1 and var8.get()==0 and var9.get()==0 \
    and var10.get()==0:
        execfile("systems/maps/logistic.py")
    #----NEW SYSTEM----------------
    elif var8.get()==1 and var9.get()==0 and var10.get()==0:
        execfile("systems/new_system/new_sys_file_write.py")
    elif var9.get()==1 and var10.get()==0:
        execfile("systems/new_system_dde/new_sys_dde_file_write.py")
    elif var10.get()==1:
        execfile("systems/new_map/new_map_file_write.py")
    else:
        print "Error2: Check olny one of the systems"

#----Popup window examples---------------------------------

#ODEs---------------------------------------------
#def selsys():
#    sstop=Toplevel()
#    sstop.title("Select ODE")
#    Label(sstop,text="Select ODE!",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=0,column=0)
#    global var1
#    global var2
#    global var3
#    global var4
#    global var5
#    global var6
#    global var8
#    global var9
#    var1 = IntVar()
#    Checkbutton(sstop, text="Lorenz System", variable=var1, font = "Helvetica 12 italic bold").grid(row=1, sticky=W)
#    var2 = IntVar()
#    Checkbutton(sstop, text="Rossler System", variable=var2, font = "Helvetica 12 italic bold").grid(row=2, sticky=W)
#    var3 = IntVar()
#    Checkbutton(sstop, text="Lotka-Volterra System", variable=var3, font = "Helvetica 12 italic bold").grid(row=3, sticky=W)

#    Label(sstop,text="Select DDE!",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=4,column=0)
#    var4 = IntVar()
#    Checkbutton(sstop, text="Mackey-Glass System", variable=var4, font = "Helvetica 12 italic bold").grid(row=5, sticky=W)
#    var5 = IntVar()
#    Checkbutton(sstop, text="Equivalent Ikeda System", variable=var5, font = "Helvetica 12 italic bold").grid(row=6, sticky=W)
#    var6 = IntVar()
#    Checkbutton(sstop, text="Half-wave Filter nl", variable=var6, font = "Helvetica 12 italic bold").grid(row=7, sticky=W)

#    global var7
#    var7 = IntVar()
#    Checkbutton(sstop, text="Mackey-Glass System", variable=var7, font = "Helvetica 12 italic bold").grid(row=8, sticky=W)

#    var8=IntVar()
#    var9=IntVar()
#    button = Button(sstop, text="Dismiss", command=sstop.destroy, bg="Red",fg="White").grid(row=10)

def selode():
    odetop=Toplevel()
    odetop.title("Select ODE")
    Label(odetop,text="Select ODE!",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=0,column=0)
    global var1
    global var2
    global var3
    global var4
    global var5
    global var6
    global var7
    global var8
    global var9
    global var10
    var1 = IntVar()
    Checkbutton(odetop, text="Lorenz System", variable=var1, font = "Helvetica 12 italic bold").grid(row=1, sticky=W)
    var2 = IntVar()
    Checkbutton(odetop, text="Rossler System", variable=var2, font = "Helvetica 12 italic bold").grid(row=2, sticky=W)
    var3 = IntVar()
    Checkbutton(odetop, text="Lotka-Volterra System", variable=var3, font = "Helvetica 12 italic bold").grid(row=3, sticky=W)

    var4=IntVar()
    var5=IntVar()
    var6=IntVar()
    var7=IntVar()
    var8=IntVar()
    var9=IntVar()
    var10=IntVar()

    button = Button(odetop, text="Close", command=odetop.destroy, bg="Red",fg="White").grid(row=4)

#DDEs---------------------------------------------
def seldde():
    ddetop=Toplevel()
    ddetop.title("Select DDE")
    Label(ddetop,text="Select DDE!",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=0,column=0)
    global var1
    global var2
    global var3
    global var4
    global var5
    global var6
    global var7
    global var8
    global var9
    global var10
    var4 = IntVar()
    Checkbutton(ddetop, text="Mackey-Glass System", variable=var4, font = "Helvetica 12 italic bold").grid(row=1, sticky=W)
    var5 = IntVar()
    Checkbutton(ddetop, text="Equivalent Ikeda System", variable=var5, font = "Helvetica 12 italic bold").grid(row=2, sticky=W)
    var6 = IntVar()
    Checkbutton(ddetop, text="Half-wave Filter nl", variable=var6, font = "Helvetica 12 italic bold").grid(row=3, sticky=W)

    var1=IntVar()
    var2=IntVar()
    var3=IntVar()
    var7=IntVar()
    var8=IntVar()
    var9=IntVar()
    var10=IntVar()

    button = Button(ddetop, text="Close", command=ddetop.destroy, bg="Red",fg="White").grid(row=4)

#MAPS----------------------------------------------
def selmap():
    maptop=Toplevel()
    maptop.title("Select MAP")
    global var1
    global var2
    global var3
    global var4
    global var5
    global var7
    global var6
    global var8
    global var9
    global var10
    var7 = IntVar()
    Checkbutton(maptop, text="Logistic Map", variable=var7, font = "Helvetica 12 italic bold").grid(row=1, sticky=W)

    var1=IntVar()
    var2=IntVar()
    var3=IntVar()
    var4=IntVar()
    var5=IntVar()
    var6=IntVar()
    var8=IntVar()
    var9=IntVar()
    var10=IntVar()

    button = Button(maptop, text="Close", command=maptop.destroy, bg="Red",fg="White").grid(row=2)

#popup window New system--------------------------
def selectsys():
    systop=Toplevel()
    systop.title("Select ODE/DDE/Map")
    Label(systop,text="Select your system!",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=0,column=0)
    global var1
    global var2
    global var3
    global var4
    global var5
    global var6
    global var7
    global var8
    global var9
    global var10
    var8 = IntVar()
    Checkbutton(systop, text="ODE New System", variable=var8, font = "Helvetica 12 italic bold").grid(row=1, sticky=W)
    var9 = IntVar()
    Checkbutton(systop, text="DDE New System", variable=var9, font = "Helvetica 12 italic bold").grid(row=2, sticky=W)
    var10 = IntVar()
    Checkbutton(systop, text="Discrete Maps", variable=var10, font="Helvetica 12 italic bold").grid(row=3,sticky=W)

    var1=IntVar()
    var2=IntVar()
    var3=IntVar()
    var4=IntVar()
    var5=IntVar()
    var6=IntVar()
    var7=IntVar()

    button = Button(systop, text="Close", command=systop.destroy, bg="Red",fg="White").grid(row=5)

#------------------------------------------
Label(master,text="Differential Equation solver!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

Label(master, text="Examples:",bg="white",fg="blue",font = "Helvetica 12 bold italic").grid(row=1, sticky=W)
#Label(master, text="ODEs:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=2, sticky=W)
Button(master, text="ODEs", command=selode, bg="Yellow",fg="Blue",font = "Helvetica 10 bold", relief=RAISED,borderwidth=4).grid(row=2, column=0, sticky=W, pady=4)
Button(master, text="DDEs", command=seldde, bg="Cyan",fg="Blue",font = "Helvetica 10 bold", relief=RAISED,borderwidth=4).grid(row=2, column=1, sticky=N, pady=4)
Button(master, text="MAPs", command=selmap, bg="Magenta",fg="Blue",font = "Helvetica 10 bold", relief=RAISED,borderwidth=4).grid(row=2, column=2, sticky=W, pady=4)

##****LORENZ*****************************
#Label(master,text="x'=sigma*(y-x), y'=r*(1-z)*x-y, z'=-b*z+x*y,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=3,column=1)
#var1 = IntVar()
#Checkbutton(master, text="Lorenz System:", variable=var1).grid(row=3, sticky=W)
##****ROSSLER*****************************
#Label(master,text="x'=-y-z, y'=x+a*y, z'=b+z*(x-c),\t      ",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=4,column=1)
#var2 = IntVar()
#Checkbutton(master, text="Rossler System:", variable=var2).grid(row=4, sticky=W)
##****LOTKA-VOLTERRA*****************************
#Label(master,text="x'=-a*x-b*x*y; y'=c*x*y-d*y,\t      ",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=5,column=1)
#var3 = IntVar()
#Checkbutton(master, text="Lotka-Volterra Eq.:", variable=var3).grid(row=5, sticky=W)

##****DDEs*****************************
#Label(master, text="-> Chaotic DDEs:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=6, sticky=W)
##****MG*****************************
#Label(master,text="x'=-a*x(t)+b*[x(t-tau)/(1-x(t-tau)^n)]\t     ,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=7,column=1)
#var4 = IntVar()
#Checkbutton(master, text="Mackey-Glass System:", variable=var4).grid(row=7, sticky=W)
##****DDEX*****************************
#Label(master,text="x'=-a*x(t)+b*[-n*x(t-tau)+m*tanh(l*x(t-tau))],",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=8,column=1)
#var5 = IntVar()
#Checkbutton(master, text="Equivalent Ikeda System:", variable=var5).grid(row=8, sticky=W)
##****DDEHW*****************************
#Label(master,text="x'=-a*x-b*(-0.5*n*(fabs(x(t-tau))+x(t-tau))+m*tanh(l*x(t-tau)))\n(Using pydelay),",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=9,column=1)
#var6 = IntVar()
#Checkbutton(master, text="Half-wave Filter nl:", variable=var6).grid(row=9, sticky=W)
##****MAPS*****************************
#Label(master, text="-> Chaotic Maps:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=10, sticky=W)
##****LOGISTIC*****************************
#Label(master,text="x_(n+1)=r*x_n*(1-x_n),",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=11,column=1)
#var7 = IntVar()
#Checkbutton(master, text="Logistic Map:", variable=var7).grid(row=11, sticky=W)
#****NEW_SYSTEMS*****************************
#Label(master, text="-> NEW SYSTEM (ODE)!:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=12, sticky=W)
##****NEW_SYSTEM*****************************
#Label(master,text="New System,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=13,column=1)
#var8 = IntVar()
#Checkbutton(master, text="New System:", variable=var8).grid(row=13, sticky=W)
##****NEW_SYSTEMS*****************************
#Label(master, text="-> NEW SYSTEM (DDE)!:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=14, sticky=W)
##****NEW_SYSTEM*****************************
#Label(master,text="New System,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=15,column=1)
#var9 = IntVar()
#Checkbutton(master, text="New System:", variable=var9).grid(row=15, sticky=W)

Label(master, text="New System:",bg="white",fg="blue",font = "Helvetica 12 bold italic").grid(row=3, sticky=W)
Button(master, text='New System (ODE/DDE/Map)', command=selectsys, bg="Yellow",fg="Blue",font = "Helvetica 10 bold", relief=RAISED,borderwidth=4).grid(row=4, column=1, sticky=W, pady=4, columnspan=3)

#*******************************************
Button(master, text='Quit', command=master.quit,bg="Red",fg="White",font = "Helvetica 12 bold italic", relief=RAISED,borderwidth=4).grid(row=5, column=0, sticky=W, pady=3)
Button(master, text='Run', command=run_prog,bg="Yellow",fg="Blue",font = "Helvetica 12 bold italic", relief=RAISED,borderwidth=4).grid(row=5, column=4, sticky=W, pady=4)
mainloop()


