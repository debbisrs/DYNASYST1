from Tkinter import *
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
t_max=100
h=0.01
print("Maximum time = "+str(t_max))
