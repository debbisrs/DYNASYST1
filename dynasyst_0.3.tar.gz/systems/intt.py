from Tkinter import *
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

#***********************************************
t_max=100
h=0.01
#t_tot = int(t_max/h)
print("Maximum time = "+str(t_max))

#*****equations***********
global equs,var
equs=[]
var=[]
u0=[]
for out in range(dim):
    equs.append(eeqq[out].get())
    var.append("x"+str(out)+"d")
    u0.append(float(inita[out].get()))
print(equs, var,u0)

#******params*************
global param
param=[]
for pp in range(parnum):
    param.append(par[pp].get())
print(param)

#    def my_prog():
##        var=u
#        with open('systems/my_program.py', 'w') as fp:
#            fp.write('from Tkinter import *\n')
#            fp.write('import numpy as np\n')
#            fp.write('from scipy.integrate import odeint\n')
#            fp.write('import matplotlib.pyplot as plt\n')
#            fp.write('import matplotlib.gridspec as gridspec\n')

#            fp.write('t_max=100\n')
#            fp.write('h=0.01\n')
#            #t_tot = int(t_max/h)
#            fp.write('print(\"Maximum time = \"+str(t_max))\n')
#        print("file has been written")

def my_int(u,t):
    varr=[]
    for xx in range(dim):
        varr.append("x"+str(xx))
    varr=u
    for ii in range(parnum):
        param[ii]=float(paramid[ii].get())
        print "par=",param[ii]
    for xx in range(dim):
        var[xx]=equs[xx]
        print "eqs:",var[xx]
    return var

t=np.arange(0,t_max,h)
print("Running ODEINT()...")
u=odeint(my_int,u0,t)   
 
print u

print("Handling Data...")
#-----To print all columns along with times--------
#====================================================
tt=np.vstack(t) # stacks row-wise
#print tt
global data
data=np.hstack((tt,u)) # stacks column-wise

datt='data.dat'
np.savetxt(datt, data)

#**************************************
winn=Tk()

winn.title("My System!")
Label(winn,text="Solve My Equation!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=0)

global paramid
paramid=[]
for pp1 in range(parnum):
    paramid.append("e"+str(pp1))
    parr1=str(param[pp1])
    parrlo=float(parlo[pp1].get())
    parrhi=float(parhi[pp1].get())
    print parrlo,parrhi, parr1
    paramid[pp1]=Scale(winn, from_=parrlo, to=parrhi,length=600, resolution=0.1, label=parr1, activebackground="green", orient=HORIZONTAL)
    paramid[pp1].grid(row=pp1, column=0)

Button(winn,text='QUIT',command=quit,bg="Red",fg="White").grid(row=7, column=0, sticky=W, pady=4)
#    Button(winn,text='SAVE_Data',command=lorenz_save_data,bg="Cyan",fg="Blue").grid(row=7, column=1, sticky=W, pady=4)
#    Button(winn,text='SAVE_Fig',command=lorenz_save,bg="Cyan",fg="Blue").grid(row=7, column=2, sticky=W, pady=4)
Button(winn,text='RUN',command=my_int,bg="Yellow",fg="Blue").grid(row=7, column=3, sticky=W, pady=4)

winn.mainloop()
