from Tkinter import *
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

#***********************************************
def my_new_syst():
    global param
    param=[]
    for pp in range(parnum):
        param.append(par[pp].get())
    print(param)

# Toplevel popup window to show variables---------------------------------------
    def vis():
        top = Toplevel()
        top.title("Visuals variables")
        global pplot
        pplot=[]
        for dimm in range(dim):
            pplot.append("pplott"+str(dimm))
            pplot[dimm] = IntVar()
            Checkbutton(top, text="x"+str(dimm), variable=pplot[dimm],font = "Helvetica 12 bold italic").grid(row=dimm+1, sticky=W)

            button = Button(top, text="Dismiss", command=top.destroy).grid(row=dim+1)
#-------------------------------------------------------------------------------

# Program to write python file in the my_program.py-----------------------------
    def my_prog():
#       var=u
       with open('systems/file_write/my_program.py', 'w') as fp:
            fp.write('from Tkinter import *\n')
            fp.write('import numpy as np\n')
            fp.write('from scipy.integrate import odeint\n')
            fp.write('import matplotlib.pyplot as plt\n')
            fp.write('import matplotlib.gridspec as gridspec\n')
            fp.write("\n")
            fp.write("t_max="+str(float(tottim.get()))+"\n")
            fp.write("h="+str(float(steph.get()))+"\n")
            #t_tot = int(t_max/h)
            fp.write('print(\"Maximum time = \"+str(t_max))\n')

            fp.write("\n")

            fp.write("def system(u,t):\n")

#            global equs,var
#            equs=[]
#            var=[]
#            u0=[]

            #To write x0,x1,x2,..=u------------
            fp.write("    ")
            for xx in range(dim):
                if xx < dim-1:
                    fp.write("x"+str(xx)+",")
                else:
                    fp.write("x"+str(xx))
            fp.write("=u\n")

            #To write parameters---------------
#            fp.write("    ")
            for pp1 in range(parnum):
                pparr=str(param[pp1])
                pparr_val=float(paramid[pp1].get())
                fp.write("    "+pparr+"="+str(pparr_val)+"\n")
#                fp.write(str(pparr_val)+"\n")
#            fp.write("\n")

            # To write equations---------------
            for out in range(dim):
                fp.write("    x"+str(out)+"d=")
                fp.write(eeqq[out].get()+"\n")

            #To write return[x0d,x1d,...]------
            fp.write("    return[")
            for out in range(dim):
                if out<dim-1:
                    fp.write("x"+str(out)+"d,")
                else:
                    fp.write("x"+str(out)+"d")
            fp.write("]\n")

            #Initial conditions----------------
            fp.write("\nu0=[")
            for dd in range(dim):
                initial_cond=float(inita[dd].get())
                if dd<dim-1:               
                    fp.write(str(initial_cond)+",")
                else:
                    fp.write(str(initial_cond))
            fp.write("]\n")
            fp.write("t=np.arange("+str(float(transient.get()))+",t_max,h)\n")
            fp.write("print(\"Running ODEINT()...\")\n")
            fp.write("u=odeint(system,u0,t)\n\n")

            fp.write("print(\"Handling Data...\")\n")
            fp.write("tt=np.vstack(t) # stacks row-wise\n")
            fp.write("global data\n")
            fp.write("data=np.hstack((tt,u))\n\n")

            fp.write("print(\"Plotting Data...\")\n")
            
            print("First="+str(int(pplot[0].get()==1)))
#            print("Second="+str(pplot[0].get()==1))
            if pplot[0].get()==1 and pplot[1].get()==0: 
                fp.write("plt.figure(0)\n")
                fp.write("plt.plot(data[:,0],data[:,1],color=\'red\')\n")
                fp.write("plt.xlabel(\"$t$\")\n")
                fp.write("plt.ylabel(\"$x(t)$\")\n")

                fp.write("\n")
                fp.write("plt.hold(False)\n")
                fp.write("plt.show()\n")
            elif pplot[1].get()==1: 
                fp.write("plt.figure(0)\n")
                fp.write("plt.plot(data[:,0],data[:,2],color=\'red\')\n")
                fp.write("plt.xlabel(\"$t$\")\n")
                fp.write("plt.ylabel(\"$x(t)$\")\n")

                fp.write("\n")
                fp.write("plt.hold(False)\n")
                fp.write("plt.show()\n")
            
            print("file has been written now RUN")
#-------------------------------------------------------------------------------

    def execute_file():
        execfile("systems/new_system/file_write/my_program.py")

#    def plot_diag():
        


    #**************************************
    winn=Tk()

    winn.title("4. My System!")
    Label(winn,text="Solve My Equation!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=0)

    global tottim
    global steph
    global transient

    #  plotting visualization------------
    Button(winn,text='Visuals',command=vis,bg="Green",fg="White").grid(row=1, sticky=W, pady=4)
    # Checkbox for plotting--------------
#    global pplot
#    pplot=[]
#    for dimm in range(dim):
#        pplot.append("pplott"+str(dimm))
#        pplot[dimm] = IntVar()
#        Checkbutton(winn, text="x"+str(dimm), variable=pplot[dimm]).grid(row=pp1+3+parnum+1+dimm, sticky=W)
#        print(str(pplot[dimm]))
    
    Label(winn,text="Total Time:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=2,column=0)
    tottim=Entry(winn)
    tottim.insert(10,"100")
    Label(winn,text="Step Size:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=2,column=2)
    steph=Entry(winn)
    steph.insert(10,"0.01")
    Label(winn,text="Transients:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=2,column=4)
    transient=Entry(winn)
    transient.insert(10,"0")

    tottim.grid(row=2, column=1)
    steph.grid(row=2, column=3)
    transient.grid(row=2, column=5)

    global paramid
    paramid=[]
    for pp1 in range(parnum):
        paramid.append("e"+str(pp1))
        parr1=str(param[pp1])
        parrlo=float(parlo[pp1].get())
        parrhi=float(parhi[pp1].get())
        print parrlo,parrhi, parr1
        paramid[pp1]=Scale(winn, from_=parrlo, to=parrhi, resolution=0.1, label=parr1, activebackground="green", orient=HORIZONTAL)
        paramid[pp1].grid(row=pp1+4, column=0,columnspan=6,sticky=W+E)

    Button(winn,text='QUIT',command=winn.destroy,bg="Red",fg="White").grid(row=pp1+4+parnum+1+dim, column=0, sticky=W, pady=4)
#    Button(winn,text='SAVE_Data',command=lorenz_save_data,bg="Cyan",fg="Blue").grid(row=7, column=1, sticky=W, pady=4)
#    Button(winn,text='SAVE_Fig',command=lorenz_save,bg="Cyan",fg="Blue").grid(row=7, column=2, sticky=W, pady=4)
    Button(winn,text='ACCEPT',command=my_prog,bg="Yellow",fg="Blue").grid(row=pp1+4+parnum+1+dim, column=2, sticky=W, pady=4)
    Button(winn,text='RUN',command=execute_file,bg="Yellow",fg="Blue").grid(row=pp1+4+parnum+1+dim, column=3, sticky=W, pady=4)

    winn.mainloop()

#**********Parameter(s) and Equation Entry Window***************
def new_syst():
    global my_new_syst
    try:
        global dim
        dim=int(e1.get())#page-104
        global parnum
        parnum=int(e2.get())
    except ValueError as err:
        print("Error: Enter both Dimension and/or No. of Parameters")

    #************New Window****************
    wind=Tk()
    wind.title("3. Parameter(s) and Equation Entry Window!")

    Label(wind,text="This is your system!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

    Label(wind,text="Parameters' name(s)!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=1,column=0)
    Label(wind,text="Parameters' range(s)!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=1,column=3)

    global par,parlo,parhi
    par=[]
    parlo=[]
    parhi=[]
    for ent1 in range(parnum):
        par.append("ee"+str(ent1))
        parlo.append("eelo"+str(ent1))
        parhi.append("eehi"+str(ent1))
#    print par, parlo,parhi        

    for ent in range(parnum):
	parr="Par_"+str(ent)
        Label(wind,text=parr,bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=0)
        par[ent]=Entry(wind)
        par[ent].grid(row=ent+2, column=1)

        Label(wind,text=",from->",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=2)
        parlo[ent]=Entry(wind)
        parlo[ent].grid(row=ent+2, column=3)

        Label(wind,text=",to->",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=4)
        parhi[ent]=Entry(wind)
        parhi[ent].grid(row=ent+2, column=5)

    Label(wind,text="Equations with parameters!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=parnum+2,column=0)
    Label(wind,text="Initial Conds!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=parnum+2,column=4)

    #******************Eqution Entry*****************
    global eeqq,inita
    eeqq=[]
    inita=[]
    for eqs1 in range(dim):
        eeqq.append("eeq"+str(eqs1))
        inita.append("init"+str(eqs1))
#        print eeq
#        print "arr=", eeqq
    #************************************************
    for eqs in range(dim):
        nam="Eq_"+str(eqs)
        naminit="Init_x"+str(eqs)
        Label(wind,text=nam,bg="white",fg="black",font="Helvetica 12 italic").grid(row=eqs+parnum+3,column=0)
        eeqq[eqs]=Entry(wind)
        eeqq[eqs].grid(row=eqs+parnum+3,column=1,columnspan=3,sticky=W+E)  
        Label(wind,text=naminit,bg="white",fg="black",font="Helvetica 12 italic").grid(row=eqs+parnum+3,column=4)
        inita[eqs]=Entry(wind)      
    	inita[eqs].grid(row=eqs+parnum+3,column=5)

    Button(wind,text='QUIT',command=quit,bg="Red",fg="White").grid(row=dim+parnum+5, column=0, sticky=W, pady=4)
    Button(wind,text='ACCEPT',command=my_new_syst,bg="Yellow",fg="Blue").grid(row=dim+parnum+5, column=3, sticky=W, pady=4)
    
    wind.mainloop()

#**************Dimension and Parameter Window********************************
win_new=Tk()

win_new.title("2. Dimension and Parameter Window!")

Label(win_new,text="This is your system!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

global e1
global e2
Label(win_new,text="Dimension:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=4,column=0)
e1=Entry(win_new)
#w2.pack()
Label(win_new,text="No. of Parameters:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=5,column=0)
e2=Entry(win_new)

e1.grid(row=4, column=1)
e2.grid(row=5, column=1)

Button(win_new,text='QUIT',command=quit,bg="Red",fg="White").grid(row=7, column=0, sticky=W, pady=4)
Button(win_new,text='ACCEPT',command=new_syst,bg="Yellow",fg="Blue").grid(row=7, column=3, sticky=W, pady=4)

win_new.mainloop()
