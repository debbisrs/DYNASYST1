from Tkinter import *
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

#***********************************************
def my_new_syst():
    t_max=100
    h=0.01
    #t_tot = int(t_max/h)
    print("Maximum time = "+str(t_max))

    #*****equations***********
    global equs,var
    equs=[]
    var=[]
    u0=[]
    for out in range(dim):
        equs.append(eeqq[out].get())
        var.append("x"+str(out)+"d")
        u0.append(float(inita[out].get()))
    print(equs, var,u0)

    #******params*************
    global param
    param=[]
    for pp in range(parnum):
        param.append(par[pp].get())
    print(param)

#    def my_prog():
##        var=u
#        with open('systems/my_program.py', 'w') as fp:
#            fp.write('from Tkinter import *\n')
#            fp.write('import numpy as np\n')
#            fp.write('from scipy.integrate import odeint\n')
#            fp.write('import matplotlib.pyplot as plt\n')
#            fp.write('import matplotlib.gridspec as gridspec\n')

#            fp.write('t_max=100\n')
#            fp.write('h=0.01\n')
#            #t_tot = int(t_max/h)
#            fp.write('print(\"Maximum time = \"+str(t_max))\n')
#        print("file has been written")

    def my_int(u,t):
        varr=[]
        for xx in range(dim):
            varr.append("x"+str(xx))
        varr=u
        for ii in range(parnum):
            param[ii]=float(paramid[ii].get())
            print "par=",param[ii]
        for xx in range(dim):
            var[xx]=equs[xx]
            print "eqs:",var[xx]
        return var

    t=np.arange(0,t_max,h)
    print("Running ODEINT()...")
    u=odeint(my_int,u0,t)   
  
    print u
 
    print("Handling Data...")
    #-----To print all columns along with times--------
    #====================================================
    tt=np.vstack(t) # stacks row-wise
    #print tt
    global data
    data=np.hstack((tt,u)) # stacks column-wise

    datt='data.dat'
    np.savetxt(datt, data)

    #**************************************
    winn=Tk()

    winn.title("My System!")
    Label(winn,text="Solve My Equation!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=0)

    global paramid
    paramid=[]
    for pp1 in range(parnum):
        paramid.append("e"+str(pp1))
        parr1=str(param[pp1])
        parrlo=float(parlo[pp1].get())
        parrhi=float(parhi[pp1].get())
        print parrlo,parrhi, parr1
        paramid[pp1]=Scale(winn, from_=parrlo, to=parrhi,length=600, resolution=0.1, label=parr1, activebackground="green", orient=HORIZONTAL)
        paramid[pp1].grid(row=pp1, column=0)

    Button(winn,text='QUIT',command=quit,bg="Red",fg="White").grid(row=7, column=0, sticky=W, pady=4)
#    Button(winn,text='SAVE_Data',command=lorenz_save_data,bg="Cyan",fg="Blue").grid(row=7, column=1, sticky=W, pady=4)
#    Button(winn,text='SAVE_Fig',command=lorenz_save,bg="Cyan",fg="Blue").grid(row=7, column=2, sticky=W, pady=4)
    Button(winn,text='RUN',command=my_int,bg="Yellow",fg="Blue").grid(row=7, column=3, sticky=W, pady=4)

    winn.mainloop()

#**********Parameter(s) and Equation Entry Window***************
def new_syst():
    global my_new_syst
    try:
        global dim
        dim=int(e1.get())#page-104
        global parnum
        parnum=int(e2.get())
    except ValueError as err:
        print("Error: Enter both Dimension and/or No. of Parameters")

    #************New Window****************
    wind=Tk()
    wind.title("Parameter(s) and Equation Entry Window!")

    Label(wind,text="This is your system!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

    Label(wind,text="Parameters' name(s)!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=1,column=0)
    Label(wind,text="Parameters' range(s)!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=1,column=3)

    global par,parlo,parhi
    par=[]
    parlo=[]
    parhi=[]
    for ent1 in range(parnum):
        par.append("ee"+str(ent1))
        parlo.append("eelo"+str(ent1))
        parhi.append("eehi"+str(ent1))
#    print par, parlo,parhi        

    for ent in range(parnum):
	parr="Par_"+str(ent)
        Label(wind,text=parr,bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=0)
        par[ent]=Entry(wind)
        par[ent].grid(row=ent+2, column=1)

        Label(wind,text=",from->",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=2)
        parlo[ent]=Entry(wind)
        parlo[ent].grid(row=ent+2, column=3)

        Label(wind,text=",to->",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=ent+2,column=4)
        parhi[ent]=Entry(wind)
        parhi[ent].grid(row=ent+2, column=5)

    Label(wind,text="Equations with parameters!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=parnum+2,column=0)
    Label(wind,text="Initial Conds!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=parnum+2,column=4)

    #******************Eqution Entry*****************
    global eeqq,inita
    eeqq=[]
    inita=[]
    for eqs1 in range(dim):
        eeqq.append("eeq"+str(eqs1))
        inita.append("init"+str(eqs1))
#        print eeq
#        print "arr=", eeqq
    #************************************************
    for eqs in range(dim):
        nam="Eq_"+str(eqs)
        naminit="Init_x"+str(eqs)
        Label(wind,text=nam,bg="white",fg="black",font="Helvetica 12 italic").grid(row=eqs+parnum+3,column=0)
        eeqq[eqs]=Entry(wind)
        eeqq[eqs].grid(row=eqs+parnum+3,column=1,columnspan=3,sticky=W+E)  
        Label(wind,text=naminit,bg="white",fg="black",font="Helvetica 12 italic").grid(row=eqs+parnum+3,column=4)
        inita[eqs]=Entry(wind)      
    	inita[eqs].grid(row=eqs+parnum+3,column=5)

    Button(wind,text='QUIT',command=quit,bg="Red",fg="White").grid(row=dim+parnum+5, column=0, sticky=W, pady=4)
    Button(wind,text='ACCEPT',command=my_new_syst,bg="Yellow",fg="Blue").grid(row=dim+parnum+5, column=3, sticky=W, pady=4)
    
    wind.mainloop()

#**************Dimension and Parameter Window********************************
win_new=Tk()

win_new.title("Dimension and Parameter Window!")

Label(win_new,text="This is your system!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

global e1
global e2
Label(win_new,text="Dimension:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=4,column=0)
e1=Entry(win_new)
#w2.pack()
Label(win_new,text="No. of Parameters:",bg="white",fg="black",font = "Helvetica 12 italic").grid(row=5,column=0)
e2=Entry(win_new)

e1.grid(row=4, column=1)
e2.grid(row=5, column=1)

Button(win_new,text='QUIT',command=quit,bg="Red",fg="White").grid(row=7, column=0, sticky=W, pady=4)
Button(win_new,text='ACCEPT',command=new_syst,bg="Yellow",fg="Blue").grid(row=7, column=3, sticky=W, pady=4)

win_new.mainloop()
